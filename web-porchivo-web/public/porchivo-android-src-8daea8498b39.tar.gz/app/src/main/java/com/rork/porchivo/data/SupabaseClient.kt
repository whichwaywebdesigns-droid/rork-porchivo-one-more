package com.rork.porchivo.data

import com.rork.porchivo.BuildConfig
import com.rork.porchivo.data.dto.DbAnnouncement
import com.rork.porchivo.data.dto.AuthSession
import com.rork.porchivo.data.dto.AuthUser
import com.rork.porchivo.data.dto.DbMyMaintenanceRequest
import com.rork.porchivo.data.dto.DbNotification
import com.rork.porchivo.data.dto.DbOrgAmenity
import com.rork.porchivo.data.dto.DbOrgAmenityReservation
import com.rork.porchivo.data.dto.DbOrgContextRow
import com.rork.porchivo.data.dto.DbOrgDocument
import com.rork.porchivo.data.dto.DbOrgPayment
import com.rork.porchivo.data.dto.DbPendingMember
import com.rork.porchivo.data.dto.DbPlanTierRow
import com.rork.porchivo.data.dto.DbProfile
import com.rork.porchivo.data.dto.DbShipment
import com.rork.porchivo.data.dto.SlotTakenException
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.patch
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.URLBuilder
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Response from the request_account_deletion RPC. */
@Serializable
data class DeletionResult(
    val success: Boolean = false,
    val error: String? = null,
    val email: String? = null,
)

/**
 * Supabase REST + Auth client using Ktor.
 *
 * - All data queries go through the PostgREST endpoint ({supabaseUrl}/rest/v1/)
 * - Auth goes through {supabaseUrl}/auth/v1/
 * - Session tokens are stored in [SessionStore] (EncryptedSharedPreferences)
 * - The anon key is sent as `apikey` header on every request
 * - The access_token is sent as `Authorization: Bearer ...` when authenticated
 */
class SupabaseClient(
    private val supabaseUrl: String,
    private val anonKey: String,
    private val sessionStore: SessionStore,
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = false
        explicitNulls = false
    }

    private val httpClient = HttpClient(Android) {
        install(ContentNegotiation) { json(this@SupabaseClient.json) }
        install(HttpTimeout) {
            requestTimeoutMillis = 20_000
            connectTimeoutMillis = 15_000
            socketTimeoutMillis = 20_000
        }
    }

    private val restBase = "$supabaseUrl/rest/v1"
    private val authBase = "$supabaseUrl/auth/v1"

    // ── Session ────────────────────────────────────────────────────────

    val currentSession: AuthSession?
        get() = sessionStore.getSession()

    val currentUserId: String?
        get() = currentSession?.user?.id

    val isAuthenticated: Boolean
        get() = currentSession != null

    // ── Auth ───────────────────────────────────────────────────────────

    suspend fun signInWithEmail(email: String, password: String): Result<AuthSession> = try {
        val response = httpClient.post("$authBase/token?grant_type=password") {
            header(HttpHeaders.ContentType, "application/json")
            header("apikey", anonKey) // gateway requires apikey on every auth call
            setBody(mapOf("email" to email, "password" to password))
        }
        if (response.status.isSuccess()) {
            val session: AuthSession = response.body()
            // Fetch user info
            val userResponse = httpClient.get("$authBase/user") {
                header("Authorization", "Bearer ${session.accessToken}")
                header("apikey", anonKey) // gateway requires apikey on every auth call
            }
            val fullSession = if (userResponse.status.isSuccess()) {
                val user: AuthUser = userResponse.body()
                session.copy(user = user)
            } else session
            sessionStore.saveSession(fullSession)
            Result.success(fullSession)
        } else {
            Result.failure(Exception("Invalid email or password"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun signUpWithEmail(email: String, password: String): Result<AuthSession> = try {
        val response = httpClient.post("$authBase/signup") {
            header(HttpHeaders.ContentType, "application/json")
            header("apikey", anonKey) // gateway requires apikey on every auth call
            setBody(mapOf("email" to email, "password" to password))
        }
        if (response.status.isSuccess()) {
            val session: AuthSession = response.body()
            if (session.accessToken.isNotBlank()) {
                sessionStore.saveSession(session)
                Result.success(session)
            } else {
                // Email confirmation required
                Result.failure(Exception("Check your email to confirm your account, then sign in."))
            }
        } else {
            Result.failure(Exception("Sign-up failed. Email may already be registered."))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Request a magic-link / OTP email from Supabase Auth.
     * Returns success if the request was accepted (the user must check email).
     */
    suspend fun sendMagicLink(email: String): Result<Unit> = try {
        val response = httpClient.post("$authBase/otp") {
            header(HttpHeaders.ContentType, "application/json")
            header("apikey", anonKey)
            setBody(
                mapOf(
                    "email" to email,
                    "options" to mapOf("should_create_user" to true),
                )
            )
        }
        if (response.status.isSuccess()) {
            Result.success(Unit)
        } else {
            val msg = parseErrorMessage(response)
            Result.failure(Exception(msg ?: "Could not send magic link. Check your email and try again."))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Verify the 6-digit OTP from the sign-in email and establish a session.
     * Existing accounts receive a magiclink token; brand-new accounts receive a
     * signup-confirmation token — both are tried before giving up.
     */
    suspend fun verifyOtp(email: String, token: String): Result<AuthSession> {
        val magicResult = verifyOtpGrant(email, token, "magiclink")
        if (magicResult.isSuccess) return magicResult
        return verifyOtpGrant(email, token, "signup")
    }

    /**
     * GoTrue has no `grant_type=otp` on the token endpoint — OTP verification
     * MUST hit `/auth/v1/verify` (the same endpoint supabase-js uses).
     */
    private suspend fun verifyOtpGrant(email: String, token: String, type: String): Result<AuthSession> = try {
        val response = httpClient.post("$authBase/verify") {
            header(HttpHeaders.ContentType, "application/json")
            header("apikey", anonKey)
            setBody(
                mapOf(
                    "email" to email,
                    "token" to token,
                    "type" to type,
                )
            )
        }
        if (response.status.isSuccess()) {
            val session: AuthSession = response.body()
            // Fetch user info
            val userResponse = httpClient.get("$authBase/user") {
                header("Authorization", "Bearer ${session.accessToken}")
                header("apikey", anonKey)
            }
            val fullSession = if (userResponse.status.isSuccess()) {
                val user: AuthUser = userResponse.body()
                session.copy(user = user)
            } else session
            sessionStore.saveSession(fullSession)
            Result.success(fullSession)
        } else {
            Result.failure(Exception(otpErrorMessage(response)))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Human-friendly message for a GoTrue verify error body (`error_code` + `msg`). */
    private suspend fun otpErrorMessage(response: io.ktor.client.statement.HttpResponse): String = try {
        val body = response.body<String>()
        val obj = json.parseToJsonElement(body).jsonObject
        when (obj["error_code"]?.jsonPrimitive?.content) {
            "otp_expired" -> "That code has expired or doesn't match. Tap Resend code and enter the code from the newest email."
            "over_email_send_rate_limit" -> "Too many code requests. Please wait a minute and try again."
            else -> obj["msg"]?.jsonPrimitive?.content ?: "Couldn't verify the code. Please try again."
        }
    } catch (_: Exception) {
        "Couldn't verify the code. Please try again."
    }

    private suspend fun parseErrorMessage(response: io.ktor.client.statement.HttpResponse): String? = try {
        val body = response.body<String>()
        val jsonObject = json.parseToJsonElement(body).jsonObject
        jsonObject["message"]?.jsonPrimitive?.content
            ?: jsonObject["error"]?.jsonPrimitive?.content
            ?: jsonObject["msg"]?.jsonPrimitive?.content
    } catch (_: Exception) {
        null
    }

    suspend fun restoreSession(): AuthSession? {
        val stored = sessionStore.getSession() ?: return null
        // Check if token is expired (with 60s buffer)
        val now = System.currentTimeMillis() / 1000
        if (stored.expiresAt > 0 && stored.expiresAt - 60 < now) {
            // Try to refresh
            refreshSession(stored.refreshToken)?.let { return it }
            // Refresh failed — clear session
            sessionStore.clearSession()
            return null
        }
        return stored
    }

    private suspend fun refreshSession(refreshToken: String): AuthSession? = try {
        val response = httpClient.post("$authBase/token?grant_type=refresh_token") {
            header(HttpHeaders.ContentType, "application/json")
            header("apikey", anonKey) // gateway requires apikey on every auth call
            setBody(mapOf("refresh_token" to refreshToken))
        }
        if (response.status.isSuccess()) {
            val session: AuthSession = response.body()
            sessionStore.saveSession(session)
            session
        } else null
    } catch (e: Exception) { null }

    fun signOut() {
        sessionStore.clearSession()
    }

    // ── REST queries ───────────────────────────────────────────────────

    private fun authHeaders(): Map<String, String> {
        val headers = mutableMapOf("apikey" to anonKey)
        currentSession?.accessToken?.let {
            headers["Authorization"] = "Bearer $it"
        }
        return headers
    }

    /** SELECT from a table with optional query params. Returns deserialized list. */
    private suspend inline fun <reified T> selectFrom(
        table: String,
        params: Map<String, String> = emptyMap(),
    ): Result<List<T>> = try {
        val urlBuilder = URLBuilder("$restBase/$table")
        params.forEach { (key, value) -> urlBuilder.parameters.append(key, value) }
        val response = httpClient.get(urlBuilder.buildString()) {
            authHeaders().forEach { (k, v) -> header(k, v) }
            header("Accept", "application/json")
        }
        if (response.status.isSuccess()) {
            val list: List<T> = response.body()
            Result.success(list)
        } else {
            Result.failure(Exception("Failed to fetch $table: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** SELECT single row from a table. */
    private suspend inline fun <reified T> selectSingle(
        table: String,
        params: Map<String, String> = emptyMap(),
    ): Result<T?> = try {
        val urlBuilder = URLBuilder("$restBase/$table")
        params.forEach { (key, value) -> urlBuilder.parameters.append(key, value) }
        urlBuilder.parameters.append("limit", "1")
        val response = httpClient.get(urlBuilder.buildString()) {
            authHeaders().forEach { (k, v) -> header(k, v) }
            header("Accept", "application/vnd.pgrst.object+json")
        }
        if (response.status.isSuccess()) {
            val item: T = response.body()
            Result.success(item)
        } else if (response.status.value == 406) {
            // No rows — PGRST116 equivalent
            Result.success(null)
        } else {
            Result.failure(Exception("Failed to fetch $table: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** INSERT into a table and return the created row. */
    private suspend inline fun <reified T> insertInto(
        table: String,
        body: Map<String, Any?>,
    ): Result<T> = try {
        val response = httpClient.post("$restBase/$table") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=representation")
            setBody(body)
        }
        if (response.status.isSuccess()) {
            val list: List<T> = response.body()
            if (list.isNotEmpty()) Result.success(list.first())
            else Result.failure(Exception("Insert returned no rows"))
        } else {
            Result.failure(Exception("Insert failed: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** PATCH (update) a row by ID. */
    private suspend inline fun <reified T> updateById(
        table: String,
        id: String,
        updates: Map<String, Any?>,
    ): Result<T> = try {
        val response = httpClient.patch("$restBase/$table?id=eq.$id") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=representation")
            setBody(updates)
        }
        if (response.status.isSuccess()) {
            val list: List<T> = response.body()
            if (list.isNotEmpty()) Result.success(list.first())
            else Result.failure(Exception("Update returned no rows"))
        } else {
            Result.failure(Exception("Update failed: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    // ── Domain operations ──────────────────────────────────────────────

    suspend fun fetchProfile(userId: String): Result<DbProfile?> =
        selectSingle("profiles", mapOf("id" to "eq.$userId"))

    suspend fun updateProfile(userId: String, updates: Map<String, Any?>): Result<DbProfile> =
        updateById("profiles", userId, updates)

    suspend fun fetchShipments(userId: String): Result<List<DbShipment>> =
        selectFrom("shipments", mapOf(
            "or" to "(homeowner_id.eq.$userId,partner_id.eq.$userId,status.eq.open)",
            "order" to "created_at.desc",
        ))

    suspend fun insertShipment(body: Map<String, Any?>): Result<DbShipment> =
        insertInto("shipments", body)

    suspend fun updateShipment(id: String, updates: Map<String, Any?>): Result<DbShipment> =
        updateById("shipments", id, updates)

    suspend fun fetchNotifications(userId: String): Result<List<DbNotification>> =
        selectFrom("notifications", mapOf(
            "recipient_id" to "eq.$userId",
            "order" to "created_at.desc",
        ))

    suspend fun markNotificationRead(id: String): Result<Unit> = try {
        val response = httpClient.patch("$restBase/notifications?id=eq.$id") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=minimal")
            setBody(mapOf("read" to true))
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Failed to mark notification read"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun markAllNotificationsRead(userId: String): Result<Unit> = try {
        val response = httpClient.patch("$restBase/notifications?recipient_id=eq.$userId&read=eq.false") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=minimal")
            setBody(mapOf("read" to true))
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Failed to mark all notifications read"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    // ── RPC ────────────────────────────────────────────────────────────

    suspend fun acceptShipment(shipmentId: String): Result<Unit> = try {
        val response = httpClient.post("$restBase/rpc/accept_shipment") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(mapOf("p_shipment_id" to shipmentId))
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Failed to accept shipment"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Graceful account deletion: stamps deletion_requested_at, bans the user
     * (invalidates sessions), and starts the 30-day grace period.
     * Returns the user's email for the confirmation email.
     */
    suspend fun requestAccountDeletion(): Result<DeletionResult> = try {
        val response = httpClient.post("$restBase/rpc/request_account_deletion") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(emptyMap<String, Any?>())
        }
        if (response.status.isSuccess()) {
            val result: DeletionResult = response.body()
            Result.success(result)
        } else {
            Result.failure(Exception("Failed to request account deletion: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Fetch published announcements for the user's org (direct table read, RLS-gated).
     */
    suspend fun fetchAnnouncements(orgId: String): Result<List<DbAnnouncement>> = try {
        val response = httpClient.get("$restBase/org_announcements") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            header("Accept", "application/json")
            url {
                parameters.append("org_id", "eq.$orgId")
                parameters.append("or", "(scheduled_at.is.null,scheduled_at.lte.now())")
                parameters.append("order", "is_pinned.desc,created_at.desc")
                parameters.append("limit", "30")
            }
        }
        if (response.status.isSuccess()) {
            val list: List<DbAnnouncement> = response.body()
            Result.success(list)
        } else {
            Result.failure(Exception("Failed to fetch announcements: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Post a new announcement (direct table insert, RLS-gated). */
    suspend fun insertAnnouncement(body: Map<String, Any?>): Result<DbAnnouncement> =
        insertInto("org_announcements", body)

    /** Submit a maintenance request via `submit_maintenance_request` RPC. Returns the new request UUID. */
    suspend fun submitMaintenanceRequest(
        orgId: String,
        category: String,
        priority: String,
        title: String,
        description: String?,
        location: String?,
    ): Result<String> = try {
        val response = httpClient.post("$restBase/rpc/submit_maintenance_request") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(buildMap<String, Any?> {
                put("p_org_id", orgId)
                put("p_category", category)
                put("p_priority", priority)
                put("p_title", title)
                description?.let { put("p_description", it) }
                location?.let { put("p_location", it) }
            })
        }
        if (response.status.isSuccess()) {
            // RPC returns a UUID string directly
            val raw: String = response.body()
            // PostgREST may return it quoted or as a JSON string
            val clean = raw.trim().removeSurrounding("\"")
            Result.success(clean)
        } else {
            Result.failure(Exception("Failed to submit maintenance request: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * File an incident in the caller's community via `file_org_incident` RPC.
     * Returns the new incident UUID.
     */
    suspend fun fileOrgIncident(
        orgId: String,
        type: String,
        severity: String,
        title: String,
        description: String?,
        unitNumber: String?,
        estimatedValue: Double?,
    ): Result<String> = try {
        val response = httpClient.post("$restBase/rpc/file_org_incident") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(buildMap<String, Any?> {
                put("p_org_id", orgId)
                put("p_type", type)
                put("p_severity", severity)
                put("p_title", title)
                description?.let { put("p_description", it) }
                unitNumber?.let { put("p_unit_number", it) }
                estimatedValue?.let { put("p_estimated_value", it) }
            })
        }
        if (response.status.isSuccess()) {
            // RPC returns a UUID string directly
            val raw: String = response.body()
            Result.success(raw.trim().removeSurrounding("\""))
        } else {
            Result.failure(Exception("Failed to file incident: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Fetch the current user's maintenance requests via `get_my_maintenance_requests` RPC. */
    suspend fun fetchMyMaintenanceRequests(orgId: String): Result<List<DbMyMaintenanceRequest>> = try {
        val response = httpClient.post("$restBase/rpc/get_my_maintenance_requests") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(mapOf("p_org_id" to orgId))
        }
        if (response.status.isSuccess()) {
            val list: List<DbMyMaintenanceRequest> = response.body()
            Result.success(list)
        } else {
            Result.success(emptyList())
        }
    } catch (e: Exception) {
        Result.success(emptyList())
    }

    /**
     * List pending join requests for the caller's org via `get_pending_members`
     * (security-definer; admin/staff enforced server-side).
     */
    suspend fun fetchPendingMembers(orgId: String): Result<List<DbPendingMember>> = try {
        val response = httpClient.post("$restBase/rpc/get_pending_members") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(mapOf("p_org_id" to orgId))
        }
        if (response.status.isSuccess()) {
            val list: List<DbPendingMember> = response.body()
            Result.success(list)
        } else {
            Result.failure(Exception("Failed to load pending members: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Approve a pending membership via `approve_org_membership`. */
    suspend fun approveOrgMembership(membershipId: String, orgId: String): Result<Unit> = try {
        val response = httpClient.post("$restBase/rpc/approve_org_membership") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(mapOf("p_membership_id" to membershipId, "p_org_id" to orgId))
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Failed to approve member: ${response.status}"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Deny a pending membership via `deny_org_membership` (row → status `removed`). */
    suspend fun denyOrgMembership(membershipId: String, orgId: String): Result<Unit> = try {
        val response = httpClient.post("$restBase/rpc/deny_org_membership") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(mapOf("p_membership_id" to membershipId, "p_org_id" to orgId))
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Failed to deny member: ${response.status}"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Fetch the current user's org memberships via `get_my_org_context` RPC.
     * Returns active + pending memberships. Empty list if the user belongs
     * to no org or the RPC is unavailable.
     */
    suspend fun fetchOrgContext(): Result<List<DbOrgContextRow>> = try {
        val response = httpClient.post("$restBase/rpc/get_my_org_context") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(emptyMap<String, Any?>())
        }
        if (response.status.isSuccess()) {
            val list: List<DbOrgContextRow> = response.body()
            Result.success(list)
        } else {
            Result.success(emptyList())
        }
    } catch (e: Exception) {
        Result.success(emptyList())
    }

    // ── Org documents + amenities (paid-tier community features) ────────

    /** All documents for the org, newest first (RLS: active members read). */
    suspend fun fetchOrgDocuments(orgId: String): Result<List<DbOrgDocument>> =
        selectFrom("org_documents", mapOf(
            "org_id" to "eq.$orgId",
            "order" to "created_at.desc",
        ))

    /** Insert a document row (RLS: staff/board only). */
    suspend fun insertOrgDocument(body: Map<String, Any?>): Result<DbOrgDocument> =
        insertInto("org_documents", body)

    suspend fun deleteOrgDocument(id: String): Result<Unit> = deleteFrom("org_documents", id)

    /** All amenities for the org, alphabetical (RLS: active members read). */
    suspend fun fetchOrgAmenities(orgId: String): Result<List<DbOrgAmenity>> =
        selectFrom("org_amenities", mapOf(
            "org_id" to "eq.$orgId",
            "order" to "name.asc",
        ))

    /** Insert an amenity (RLS: staff/board only, UNIQUE(org_id, name)). */
    suspend fun insertOrgAmenity(body: Map<String, Any?>): Result<DbOrgAmenity> =
        insertInto("org_amenities", body)

    suspend fun deleteOrgAmenity(id: String): Result<Unit> = deleteFrom("org_amenities", id)

    /**
     * Upcoming confirmed reservations with the booker's profile name embedded
     * (`select=*,member:profiles(name)`), earliest first.
     */
    suspend fun fetchOrgAmenityReservations(orgId: String): Result<List<DbOrgAmenityReservation>> = try {
        val nowIso = java.time.Instant.now().toString()
        val response = httpClient.get("$restBase/org_amenity_reservations") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            header("Accept", "application/json")
            url {
                parameters.append("select", "*,member:profiles(name)")
                parameters.append("org_id", "eq.$orgId")
                parameters.append("status", "eq.confirmed")
                parameters.append("starts_at", "gte.$nowIso")
                parameters.append("order", "starts_at.asc")
                parameters.append("limit", "200")
            }
        }
        if (response.status.isSuccess()) {
            val list: List<DbOrgAmenityReservation> = response.body()
            Result.success(list)
        } else {
            Result.failure(Exception("Failed to fetch reservations: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Insert a reservation. Double-booking is blocked by the DB-level GiST
     * EXCLUDE constraint — a 23P01 exclusion violation maps to [SlotTakenException].
     */
    suspend fun insertOrgAmenityReservation(body: Map<String, Any?>): Result<DbOrgAmenityReservation> = try {
        val response = httpClient.post("$restBase/org_amenity_reservations") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=representation")
            setBody(body)
        }
        if (response.status.isSuccess()) {
            val list: List<DbOrgAmenityReservation> = response.body()
            if (list.isNotEmpty()) Result.success(list.first())
            else Result.failure(Exception("Insert returned no rows"))
        } else {
            if (parseErrorCode(response) == "23P01") Result.failure(SlotTakenException())
            else Result.failure(Exception(parseErrorMessage(response) ?: "Reservation failed"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Cancel a reservation (RLS: own booking or staff). */
    suspend fun cancelOrgAmenityReservation(id: String): Result<Unit> = try {
        val response = httpClient.patch("$restBase/org_amenity_reservations?id=eq.$id") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=minimal")
            setBody(mapOf("status" to "cancelled"))
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Failed to cancel reservation"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Fetch the org's plan tier (null on failure — callers fail open). */
    suspend fun fetchOrgPlanTier(orgId: String): Result<DbPlanTierRow?> =
        selectSingle("organizations", mapOf("id" to "eq.$orgId", "select" to "plan_tier"))

    /** Full payment ledger for the org, newest first (RLS: staff/board read). */
    suspend fun fetchOrgPayments(orgId: String): Result<List<DbOrgPayment>> = try {
        val response = httpClient.get("$restBase/org_payments") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            header("Accept", "application/json")
            url {
                parameters.append("select", "*,member:profiles(name)")
                parameters.append("org_id", "eq.$orgId")
                parameters.append("order", "created_at.desc")
                parameters.append("limit", "500")
            }
        }
        if (response.status.isSuccess()) {
            val list: List<DbOrgPayment> = response.body()
            Result.success(list)
        } else {
            Result.failure(Exception("Failed to fetch payments: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Upload bytes to the private `org-documents` bucket under the org's folder. */
    suspend fun uploadOrgDocObject(path: String, data: ByteArray, mime: String): Result<Unit> = try {
        val response = httpClient.post("$supabaseUrl/storage/v1/object/org-documents/$path") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.parse(mime))
            header("x-upsert", "false")
            setBody(data)
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Upload failed (${response.status.value})"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Create a 300-second signed URL for a private org document. */
    suspend fun createOrgDocSignedUrl(path: String): Result<String> = try {
        val response = httpClient.post("$supabaseUrl/storage/v1/object/sign/org-documents/$path") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(mapOf("expiresIn" to 300))
        }
        if (response.status.isSuccess()) {
            val body = response.body<String>()
            val signed = json.parseToJsonElement(body).jsonObject["signedURL"]?.jsonPrimitive?.content
            if (signed != null) Result.success("$supabaseUrl/storage/v1$signed")
            else Result.failure(Exception("Could not create a link for this document"))
        } else {
            Result.failure(Exception("Link expired — try again."))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    // ── Storage (avatars) ───────────────────────────────────────────────

    /**
     * Upload avatar bytes to the public-read `avatars` bucket under
     * `<userId>/<timestamp>.<ext>` and return the cache-busted public URL.
     * Mirrors expo/lib/avatar.ts uploadAvatar.
     */
    suspend fun uploadAvatarObject(userId: String, data: ByteArray, mime: String): Result<String> = try {
        val ext = when (mime) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/gif" -> "gif"
            else -> "jpg"
        }
        val path = "$userId/${System.currentTimeMillis()}.$ext"
        val response = httpClient.post("$supabaseUrl/storage/v1/object/avatars/$path") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.parse(mime))
            header("x-upsert", "true")
            setBody(data)
        }
        if (response.status.isSuccess()) {
            Result.success("$supabaseUrl/storage/v1/object/public/avatars/$path?t=${System.currentTimeMillis()}")
        } else {
            Result.failure(Exception("Upload failed (${response.status.value})"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Best-effort delete of an avatar object extracted from a public URL (non-fatal). */
    suspend fun deleteAvatarObject(publicUrl: String) {
        try {
            val marker = "/object/public/avatars/"
            val start = publicUrl.indexOf(marker)
            if (start < 0) return
            val path = publicUrl.substring(start + marker.length).substringBefore('?')
            if (path.isBlank()) return
            httpClient.delete("$supabaseUrl/storage/v1/object/avatars/$path") {
                authHeaders().forEach { (k, v) -> header(k, v) }
            }
        } catch (_: Exception) {
            // Profile row is the source of truth; an orphaned object is harmless.
        }
    }

    /**
     * PATCH a profile column to explicit SQL NULL. Used for avatar removal —
     * Map-based bodies go through kotlinx serialization, which can drop null
     * map entries, so the JSON body is built literally here.
     */
    suspend fun clearProfileField(userId: String, field: String): Result<DbProfile> = try {
        val response = httpClient.patch("$restBase/profiles?id=eq.$userId") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            header("Prefer", "return=representation")
            setBody("""{"$field":null}""")
        }
        if (response.status.isSuccess()) {
            val list: List<DbProfile> = response.body()
            if (list.isNotEmpty()) Result.success(list.first())
            else Result.failure(Exception("Update returned no rows"))
        } else {
            Result.failure(Exception("Update failed: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Best-effort delete of a bucket object (non-fatal if it fails). */
    suspend fun deleteOrgDocObject(path: String): Boolean = try {
        val response = httpClient.delete("$supabaseUrl/storage/v1/object/org-documents/$path") {
            authHeaders().forEach { (k, v) -> header(k, v) }
        }
        response.status.isSuccess()
    } catch (_: Exception) {
        false
    }

    private suspend fun parseErrorCode(response: io.ktor.client.statement.HttpResponse): String? = try {
        val body = response.body<String>()
        json.parseToJsonElement(body).jsonObject["code"]?.jsonPrimitive?.content
    } catch (_: Exception) {
        null
    }

    /** DELETE a row by id (Prefer: return=minimal). */
    private suspend inline fun deleteFrom(table: String, id: String): Result<Unit> = try {
        val response = httpClient.delete("$restBase/$table?id=eq.$id") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            header("Prefer", "return=minimal")
        }
        if (response.status.isSuccess()) Result.success(Unit)
        else Result.failure(Exception("Delete failed: ${response.status}"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    // ── Edge Functions ───────────────────────────────────────────────────

    /**
     * Invoke a Supabase Edge Function by name.
     * Uses {supabaseUrl}/functions/v1/{name} with the user's auth token.
     */
    suspend fun <T> invokeFunction(
        name: String,
        body: Map<String, Any?>,
        responseType: kotlinx.serialization.KSerializer<T>,
    ): Result<T> = try {
        val response = httpClient.post("$supabaseUrl/functions/v1/$name") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(body)
        }
        if (response.status.isSuccess()) {
            val responseText = response.body<String>()
            val result = json.decodeFromString(responseType, responseText)
            Result.success(result)
        } else {
            Result.failure(Exception("Function $name failed: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    /**
     * Invoke a Supabase Edge Function by name without deserializing the response.
     * Used for fire-and-forget calls like dev-confirm-user where only success/failure matters.
     */
    suspend fun invokeFunctionRaw(
        name: String,
        body: Map<String, Any?>,
    ): Result<Unit> = try {
        val response = httpClient.post("$supabaseUrl/functions/v1/$name") {
            authHeaders().forEach { (k, v) -> header(k, v) }
            contentType(ContentType.Application.Json)
            setBody(body)
        }
        if (response.status.isSuccess()) {
            Result.success(Unit)
        } else {
            Result.failure(Exception("Function $name failed: ${response.status}"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    // ── Offline queue replay ───────────────────────────────────────────

    /**
     * Replay a queued action against Supabase REST. Used by the offline
     * action queue when connectivity is restored. Returns true on HTTP success.
     */
    suspend fun replayQueuedAction(
        type: String,
        target: String,
        payload: String,
        filter: Map<String, String>? = null,
    ): Boolean {
        return try {
            when (type) {
                "insert" -> {
                    val response = httpClient.post("$restBase/$target") {
                        authHeaders().forEach { (k, v) -> header(k, v) }
                        contentType(ContentType.Application.Json)
                        header("Prefer", "return=minimal")
                        setBody(payload)
                    }
                    response.status.isSuccess()
                }
                "update" -> {
                    val query = filter?.entries?.joinToString("&") { "${it.key}=eq.${it.value}" } ?: ""
                    val url = if (query.isNotEmpty()) "$restBase/$target?$query" else "$restBase/$target"
                    val response = httpClient.patch(url) {
                        authHeaders().forEach { (k, v) -> header(k, v) }
                        contentType(ContentType.Application.Json)
                        header("Prefer", "return=minimal")
                        setBody(payload)
                    }
                    response.status.isSuccess()
                }
                "rpc" -> {
                    val response = httpClient.post("$restBase/rpc/$target") {
                        authHeaders().forEach { (k, v) -> header(k, v) }
                        contentType(ContentType.Application.Json)
                        setBody(payload)
                    }
                    response.status.isSuccess()
                }
                else -> false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun close() {
        httpClient.close()
    }
}
