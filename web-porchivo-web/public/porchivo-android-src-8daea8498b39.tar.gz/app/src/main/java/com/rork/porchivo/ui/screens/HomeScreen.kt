package com.rork.porchivo.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.GppMaybe
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.rork.porchivo.model.Announcement
import com.rork.porchivo.data.MockData
import com.rork.porchivo.data.LoadState
import com.rork.porchivo.ui.components.EmptyState
import com.rork.porchivo.ui.components.ShipmentCard
import com.rork.porchivo.ui.components.pressScale
import com.rork.porchivo.ui.components.rememberPressHaptic
import com.rork.porchivo.ui.navigation.Routes
import com.rork.porchivo.ui.theme.PorchivoTheme
import com.rork.porchivo.ui.viewmodel.AppViewModel
import com.rork.porchivo.ui.viewmodel.NotificationsViewModel
import com.rork.porchivo.ui.viewmodel.ShipmentsViewModel
import com.rork.porchivo.util.RiskEngine
import com.rork.porchivo.util.SafetyScore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    appViewModel: AppViewModel = viewModel(),
    shipmentsViewModel: ShipmentsViewModel = viewModel(),
    notificationsViewModel: NotificationsViewModel = viewModel(),
) {
    val c = PorchivoTheme.colors
    val pressHaptic = rememberPressHaptic()
    val user by appViewModel.user.collectAsStateWithLifecycle()
    val myShipments by shipmentsViewModel.myShipments.collectAsStateWithLifecycle()
    val unreadCount by notificationsViewModel.unreadCount.collectAsStateWithLifecycle()
    val shipmentsLoadState by shipmentsViewModel.shipmentsLoadState.collectAsStateWithLifecycle()
    val announcements by appViewModel.announcements.collectAsStateWithLifecycle()

    val safetyScore = remember(myShipments) { SafetyScore.fromRisk(RiskEngine.score(myShipments)) }
    val theftFact = remember {
        val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        MockData.theftFacts[dayOfYear % MockData.theftFacts.size]
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(c.background),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                text = "Porchivo",
                color = c.textPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
            )
        }

        item { TheftFactCard(fact = theftFact) }

        if (appViewModel.isOrgMember && announcements.isNotEmpty()) {
            item { AnnouncementsPreview(announcements = announcements.take(3)) }
        }

        item {
            CreateEntryBanner(onClick = { pressHaptic(); navController.navigate(Routes.CREATE) })
        }

        item {
            TodayRiskCard(
                score = safetyScore,
                onClick = { pressHaptic(); navController.navigate(Routes.SAFETY) },
            )
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Hello, ${user?.name?.substringBefore(' ') ?: "there"}",
                        color = c.textPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.4).sp,
                    )
                    Text(
                        text = "Your delivery dashboard",
                        color = c.textSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(c.accent, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = c.onAccent,
                        modifier = Modifier.size(14.dp),
                    )
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickLink(
                    label = "Alerts",
                    icon = Icons.Outlined.Notifications,
                    tint = c.danger,
                    softTint = c.dangerSoft,
                    badge = unreadCount,
                    onClick = { pressHaptic(); navController.navigate(Routes.ACTIVITY) },
                )
                QuickLink(
                    label = "Safety",
                    icon = Icons.Outlined.BarChart,
                    tint = c.accent,
                    softTint = c.accentSoft,
                    onClick = { pressHaptic(); navController.navigate(Routes.SAFETY) },
                )
                QuickLink(
                    label = "Add Package",
                    icon = Icons.Filled.Add,
                    tint = c.success,
                    softTint = c.successSoft,
                    onClick = { pressHaptic(); navController.navigate(Routes.ADD_PACKAGE) },
                )
                QuickLink(
                    label = "Incident",
                    icon = Icons.Outlined.ReportProblem,
                    tint = c.warmOrange,
                    softTint = c.warmOrangeSoft,
                    onClick = { pressHaptic(); navController.navigate(Routes.FILE_INCIDENT) },
                )
            }
        }

        item {
            Text(
                text = "My Shipments",
                color = c.textPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
        }

        if (myShipments.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Outlined.Shield,
                    title = "No packages yet",
                    body = "Add your first package to start tracking deliveries and scoring porch risk.",
                    ctaLabel = "Add your first package",
                    onCta = { pressHaptic(); navController.navigate(Routes.ADD_PACKAGE) },
                )
            }
        } else {
            items(myShipments, key = { it.id }) { shipment ->
                ShipmentCard(
                    shipment = shipment,
                    onClick = { pressHaptic(); navController.navigate(Routes.shipmentDetail(shipment.id)) },
                    modifier = Modifier.animateItem(),
                )
            }
        }
    }
}

@Composable
private fun TheftFactCard(fact: String, modifier: Modifier = Modifier) {
    val c = PorchivoTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(c.peach, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = Icons.Outlined.Shield,
            contentDescription = null,
            tint = c.warmOrange,
            modifier = Modifier.size(20.dp),
        )
        Column {
            Text(
                text = "DAILY THEFT FACT",
                color = c.warmOrange,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp,
            )
            Text(
                text = fact,
                color = c.textPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun CreateEntryBanner(onClick: () -> Unit, modifier: Modifier = Modifier) {
    // Home → CREATE route, which on Android is the New Shipment form (no
    // 4-card menu like iOS). Copy matches that destination exactly — an
    // earlier version said "Create / Log activity for your block or
    // building", which didn't describe a shipment-posting form.
    val c = PorchivoTheme.colors
    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .pressScale(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = c.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .background(c.accentSoft, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = null,
                    tint = c.accent,
                    modifier = Modifier.size(15.dp),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Post a shipment",
                    color = c.textPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "Let a Porch Partner protect your delivery",
                    color = c.textSecondary,
                    fontSize = 11.sp,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = c.accent,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
private fun TodayRiskCard(score: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = PorchivoTheme.colors
    // Displayed as a SAFETY score (higher = safer) via the shared helper.
    val safety = SafetyScore.fromRisk(score)
    val band = SafetyScore.band(safety)
    val tint = when (band) {
        RiskEngine.RiskLevel.HIGH -> c.danger
        RiskEngine.RiskLevel.MEDIUM -> c.warmOrange
        RiskEngine.RiskLevel.LOW -> c.success
    }

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .pressScale(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = c.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "TODAY'S SAFETY",
                    color = c.textMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.4.sp,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = band.label,
                    color = tint,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(tint.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "$safety",
                    color = c.textPrimary,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-1.4).sp,
                )
                Text(
                    text = " / 100",
                    color = c.textMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { safety / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = tint,
                trackColor = c.elevated,
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "View breakdown →",
                color = c.accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun QuickLink(
    label: String,
    icon: ImageVector,
    tint: Color,
    softTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badge: Int = 0,
) {
    val c = PorchivoTheme.colors
    Card(
        onClick = onClick,
        modifier = modifier
            .width(76.dp)
            .pressScale(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(softTint, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = tint,
                        modifier = Modifier.size(18.dp),
                    )
                }
                if (badge > 0) {
                    Badge(
                        containerColor = c.danger,
                        modifier = Modifier.align(Alignment.TopEnd),
                    ) {
                        Text(text = if (badge > 9) "9+" else "$badge")
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                color = c.textSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun AnnouncementsPreview(announcements: List<Announcement>, modifier: Modifier = Modifier) {
    val c = PorchivoTheme.colors
    val dateFormat = remember { SimpleDateFormat("MMM d", Locale.getDefault()) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = c.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Outlined.Campaign,
                    contentDescription = null,
                    tint = c.warmOrange,
                    modifier = Modifier.size(14.dp),
                )
                Text(
                    text = "ANNOUNCEMENTS",
                    color = c.warmOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            announcements.forEachIndexed { index, item ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = item.title,
                        color = c.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    Text(
                        text = item.body,
                        color = c.textSecondary,
                        fontSize = 12.sp,
                        maxLines = 2,
                    )
                    Text(
                        text = dateFormat.format(Date(item.createdAt)),
                        color = c.textMuted,
                        fontSize = 11.sp,
                    )
                }
                if (index < announcements.lastIndex) {
                    Spacer(modifier = Modifier.height(6.dp))
                    androidx.compose.material3.HorizontalDivider(color = c.border)
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}
